package adt.stack;

import adt.linkedList.SingleLinkedListNode;

/**
 * Classe que representa um apilha implementada usando-se um noh de uma lista
 * simplesmente ligada, como estrutura sobrejacente.
 * 
 * Restricoes: - voce DEVE obedecer a politica de acesso e complexidade dos
 * metodos de pilha, ou seja, todos em O(1). - voce NÃO pode usar memoria extra
 * (estrutura auxiliar) - qualquer metodo auxiliar que voce necessite DEVE ser
 * implementado nesta classe - voce NÃO pode modificar a classe
 * SingleLinkedListNode
 * 
 * @author adalbertocajueiro
 *
 * @param <T>
 */
public class StackSingleLinkedListNodeImpl<T> implements Stack<T> {

	private SingleLinkedListNode<T> top;
	private int size;
	private int elements;

	/**
	 * A pilha para ser criada precisa ter um tamanho maximo
	 * 
	 * @param tamanhoMaximo
	 */
	public StackSingleLinkedListNodeImpl(int tamanhoMaximo) {
		this.top = new SingleLinkedListNode<T>();
		size = tamanhoMaximo;
		elements = 0;
	}

	@Override
	public void push(T element) throws StackOverflowException {
		if (! isFull()) {
			if (element != null) {
				SingleLinkedListNode<T> aux = new SingleLinkedListNode<T>(element, top);
				this.top = aux;
				elements++;
			}
		} else {
			throw new StackOverflowException();
		}
	}

	@Override
	public T pop() throws StackUnderflowException {
		T data = null;
		if (!isEmpty()) {
			data = top.getData();
			T newdata = top.getNext().getData();
			top.setData(newdata);
			top.setNext(top.getNext().getNext());
			elements--;
		} else
			throw new StackUnderflowException();

		return data;
	}

	@Override
	public T top() {
		T data;
		data = top.getData();
		if (isEmpty())
			data = null;
		return data;
	}

	@Override
	public boolean isEmpty() {
		return elements == 0;
	}

	@Override
	public boolean isFull() {
		return size == elements;
	}



}
