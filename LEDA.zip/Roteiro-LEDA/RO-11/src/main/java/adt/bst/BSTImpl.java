package adt.bst;

public class BSTImpl<T extends Comparable<T>> implements BST<T> {

	protected BSTNode<T> root;

	public BSTImpl() {
		root = new BSTNode<T>();
	}

	public BSTNode<T> getRoot() {
		return this.root;
	}

	@Override
	public boolean isEmpty() {
		return root.isEmpty();
	}

	@Override
	public int height() {
		return getHeight(root);
		
	}

	@Override
	public BSTNode<T> search(T element) {
		BSTNode<T> aux = root;
		while(aux.getData().compareTo(element) != 0 && !aux.isEmpty()) {
			if (aux.getData().compareTo(element) > 0)
				aux = (BSTNode<T>) aux.getLeft();
			else
				aux = (BSTNode<T>) aux.getLeft();
		}
		
		return aux;
		
	}

	@Override
	public void insert(T element) {
		BSTNode<T> aux = root;
		while(!aux.isEmpty()) {
			if (aux.getData().compareTo(element) > 0) 
				aux = (BSTNode<T>) aux.getRight();
			if (aux.getData().compareTo(element) < 0) 
				aux = (BSTNode<T>) aux.getLeft();
				
			}
			
		aux.setData(element);
		aux.setLeft(new BSTNode<T>());
		aux.setRight(new BSTNode<T>());
			
		
	}

	@Override
	public BSTNode<T> maximum() {
		BSTNode aux = root;
		while(!aux.isLeaf()) {
			aux = (BSTNode) aux.getRight();
		}
		return aux;
	}

	@Override
	public BSTNode<T> minimum() {
		BSTNode aux = root;
		while(!aux.isLeaf()) {
			aux = (BSTNode) aux.getLeft();
		}
		return aux;
		
	}

	@Override
	public BSTNode<T> sucessor(T element) {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Not implemented yet!");
	}

	@Override
	public BSTNode<T> predecessor(T element) {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Not implemented yet!");
	}

	@Override
	public void remove(T element) {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Not implemented yet!");
	}

	@Override
	public T[] preOrder() {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Not implemented yet!");
	}

	@Override
	public T[] order() {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Not implemented yet!");
	}

	@Override
	public T[] postOrder() {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Not implemented yet!");
	}

	/**
	 * This method is already implemented using recursion. You must understand
	 * how it work and use similar idea with the other methods.
	 */
	@Override
	public int size() {
		return size(root);
	}

	private int size(BSTNode<T> node) {
		int result = 0;
		// base case means doing nothing (return 0)
		if (!node.isEmpty()) { // indusctive case
			result = 1 + size((BSTNode<T>) node.getLeft())
					+ size((BSTNode<T>) node.getRight());
		}
		return result;
	}
	
	
	private int getHeight(BSTNode<T> node) {
		int altura = 0;
		int alturaDireita = 0;
		int alturaEsquerda = 0;
		if (!node.isEmpty()) {
			alturaDireita = getHeight((BSTNode<T>) node.getRight());
			alturaEsquerda = getHeight((BSTNode<T>) node.getLeft());
			
			 if (alturaDireita > alturaEsquerda)
				 altura = 1 + alturaDireita;
			 else
				 altura = 1 + alturaEsquerda;
		}
		return altura;
	}
	
	private BSTNode<T> auxSearch(BSTNode<T> node, T element){
		BSTNode aux;
		if (node.getData() == element)
			aux = node;
		
		
		return;
	}

}
