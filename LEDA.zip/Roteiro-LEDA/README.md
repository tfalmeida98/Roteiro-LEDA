# Roteiro-LEDA
Roteiros da cadeira de LEDA-UFCG
