module ADC {
	requires org.junit.jupiter.api;
}